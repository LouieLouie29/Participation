﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Toys
{
    class ToyBox
    {
        

        public List<string> Toys { get; set; }

        public ToyBox()
        {
            Name = new List<string>();
            Price = new List<string>();
        }

        
    }
}
